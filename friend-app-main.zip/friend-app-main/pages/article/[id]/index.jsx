import ProductPageContent from "../../../components/ProductPageContent"
import products from '../../../data/mattress.json'
import pillow from '../../../data/pillow.json'
import protectors from '../../../data/protector.json'
import { useRouter } from 'next/router'
export default function ProductPage ({product}) {
    [product]=product
    const router = useRouter()
  return (<>
    <div className="min-h-screen py-12 sm:pt-20">
      <ProductPageContent product={product} />
    </div>
    <div className=" max-w-md mx-auto flex justify-center items-center md:mt-8">
        <a className="inline-flex items-center justify-center h-12 px-6 mr-6 font-medium py-3 border-transparent rounded-md text-white bg-gray-900 hover:bg-gray-800" onClick={() => router.back()}>
          Go Back 
        </a>
      
      </div>
    </>
  )
}

export const getStaticProps = async (context) => {
    let product
    const id = context.params.id 
    if(id<11){
        if (id<5) {
            product = products.filter(product=>product.id==id)
        } else if (id<8) {
         product = pillow.filter(product=>product.id==id)


        } else {
         product = protectors.filter(product=>product.id==id)



        }
       }




if(product.length > 0 ){
    product


} else{
    json(`we are not found data with id ${id} `)
}
         return {
             props:{
                product 
             }
         }
 }
export const getStaticPaths = async () => {

    return {
        paths:[
            {
                params: {id: '1'}
            },
            {
                params: {id: '2'}
            },
            {
                params: {id: '3'}
            },
            {
                params: {id: '4'}
            },
            {
                params: {id: '5'}
            },
             {
                params: {id: '6'}
            },
             {
                params: {id: '7'}
            },
             {
                params: {id: '8'}
            },
            {
               params: {id: '9'}
           },
           {
              params: {id: '10'}
          }
        ],
        fallback:false  
    }
}

