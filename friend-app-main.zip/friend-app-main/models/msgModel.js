const mongoose = require('mongoose');
const massage = new mongoose.Schema({
    user:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'Ru'
    },
    username:{
        type:String,
        required:true
    },
    text :{
        type:String,
        required:true
    },
    date :{
        type:Date,
        default:Date.now
    }
})
module.exports = mongoose.models.msg || mongoose.model('msg',massage)