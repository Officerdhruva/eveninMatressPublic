import dbConnect from "../../dbconnection/connectdb";
import Ru from "../../models/model";
import authurize from "../../helper/authuraizatiion";

const myprofile =async (req,res)=>{

    try{
        await dbConnect();
        
         const userid = req.user.id;
       const user=  await Ru.findById(userid);
    // const user = await Ru.findOne({userid})
         if(!user){
             res.send('user does not exist');

         }
        return res.json(user);

    }
    catch(err){
        console.log(err)
    }
}
export default authurize(myprofile)