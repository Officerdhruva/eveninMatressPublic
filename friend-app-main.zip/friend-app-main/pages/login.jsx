import { useState } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';
import {  FaRegEnvelope } from "react-icons/fa";
import {MdLockOutline} from 'react-icons/md';
import axios from 'axios';
import { useContext } from 'react';
import { store } from './_app';
export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [token,setToken]=useContext(store);
  const [data,setData]=useState(null);
const router = useRouter();
  const submitHandler =(e)=>{
      e.preventDefault();

      if(password.length<=4){

        setData('please enter password')
      }

      
      
       if(password.length>4){
        axios.post('http://localhost:3000/api/login',{email,password}).then(res=>{
          if(res.data.token) throw setToken(res.data.token);
           setData(res.data)
           
          })
      }
      
  }
  if(token){
  router.push('/myprofile')
  }
  return (
<div className="flex flex-col items-center justify-center min-h-screen py-2 bg-gray-100">


  <Head>
   <title> Login page </title>
   <link rel="icon" href="/favicon.ico"/>
  </Head>
  <main className=' flex flex-col items-center justify-center w-full flex-1 lg:px-20  px-2 text-center '>
    <div className=' bg-white    rounded-2xl shadow-2xl   max-w-4xl '>
      <div className=' flex  justify-center  p-10 ' >
      <form onSubmit={submitHandler}>

        <div className=' text-center font-bold   '>
          <span className='  text-green-500'>Evinin</span> Matress
        </div>
          <h2 className=' text-3xl font-bold text-green-500 mb-2'> Sign  in to Account </h2> 
        <div className=' border-2 w-10 border-green-500 bg-green-500 rounded-full inline-block mb-2'></div>
 
   {/* complete icons section    */}
<div className=' flex flex-col items-center'>
<div className=' bg-gray-100 w-64 p-2 flex items-center mb-3'>
  <FaRegEnvelope className=' text-gray-500 mr-2 '/>
  <input type="email" name="email" placeholder='Enter email' value={email} onChange={e=>setEmail(e.target.value)} className=' bg-gray-100 outline-none text-sm    flex-1' />

</div>
<div className=' bg-gray-100 w-64 p-2 flex items-center mb-3'>
  <MdLockOutline className=' text-gray-500 mr-2'/>
  <input type="password" name="password"  placeholder='Enter password' value={password} onChange={e=>setPassword(e.target.value)} className=' bg-gray-100 outline-none text-sm    flex-1' />

</div>
      </div>
      <p className=' text-sm'>{data}</p>
<button href="#" className=' border-2    outline-none mt-5 border-green-500  text-green-500 rounded-full px-12 py-2 inline-block  hover:bg-green-500  hover:text-white'>Login </button>

</form>
        </div>
     
     
    </div>
    
  </main>
</div>
    )
}




