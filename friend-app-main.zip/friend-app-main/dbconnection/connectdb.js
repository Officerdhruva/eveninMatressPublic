const mongoose = require('mongoose');

 



async function dbConnect() {
    

    const  db= mongoose.connect("mongodb+srv://king:iTX1HnrhKy2bDEAy@cluster0.p5xe1.mongodb.net/myFirstDatabase?retryWrites=true&w=majority", {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    }).then(()=>console.log('db connected'))
}

export default dbConnect;