import dbConnect from '../../dbconnection/connectdb'
 import Ru from '../../models/model'


export default async function handler(req,res){
    try{
    await dbConnect();
    
    const {username,email,password,conformpassword}=req.body;
    
    const exist =await Ru.findOne({email});
    
    if(exist){
        return res.send('user already exist');
    }
    if(password!==conformpassword){
        return res.send('passwords are not mached');

    }
    let newUser = new Ru({
        username,
        email,
        password,
        conformpassword
    })
    await newUser.save();
     return res.send('Rigister succesfully')
 

        
}
catch(err){
    console.log(err);
    res.send('server error')
}
}