import 'tailwindcss/tailwind.css'
import 'swiper/scss'
import 'swiper/scss/navigation'
import 'swiper/scss/pagination'
import Layout from '../Components/Layout'
import { createContext, useState } from 'react'
export const store = createContext();

function MyApp({ Component, pageProps }) {
  const [token, setToken] = useState(null);
  return (
  <store.Provider value={[token,setToken]}>

  <Layout>
    <Component {...pageProps} />

  </Layout>
  </store.Provider>

  )
}

export default MyApp
