import { store } from "./_app";
import { useContext, useState } from "react";
import { useRouter } from "next/router";
import Head from "next/head";
import { useEffect } from "react";
import axios from "axios";
const Myprofile = () => {
  const [token, setToken] = useContext(store);
  const [data, setData] = useState(null);
  const router = useRouter();
  
  

  useEffect(() => {
    if (!token) {
      router.push("/login");
    }
    axios
      .get("/api/myprofile", {
        headers: {
          token,
        },
      })
      .then((res) => setData(res.data))
      .catch((err) => console.log(err));
    
      
  }, [token]);
  
  

  return (
    <>
      <div className="flex flex-col items-center justify-center min-h-screen py-2 bg-gray-100">
        <Head>
          <title> My profile </title>
          <link rel="icon" href="/favicon.ico" />
        </Head>
        <main className=" flex flex-col items-center justify-center w-full flex-1 lg:px-20  px-2 text-center ">
          <div className=" bg-white    rounded-2xl shadow-2xl   max-w-4xl ">
            <div className=" flex  justify-center  p-10 ">
             
              <div>
                <div className=" text-center font-bold   ">
                  <span className="  text-green-500">Evinin</span> Matress
                </div>
                <h2 className=" text-3xl font-bold text-green-500 mb-2">
                
                { data && data.username} 
              </h2>
              <div className=" border-2 w-10 border-green-500 bg-green-500 rounded-full inline-block mb-2"></div>
              <h2 className=" text-3xl font-bold text-green-500 mb-2">
               
                { data && data.email}
              </h2>

              <div className=" border-2 w-10 border-green-500 bg-green-500 rounded-full inline-block mb-2"></div>
               

                <div>
                 
                  <a
                    onClick={() => setToken(null)}
                    className=" border-2    outline-none   mt-5 border-green-500  text-green-500 rounded-full px-12 py-2 inline-block  hover:bg-green-500  hover:text-white"
                  >
                    Logout
                  </a>
                </div>
              </div>
            </div>
          </div>
        
        </main>
      </div>
    </>
  );
};

export default Myprofile;
