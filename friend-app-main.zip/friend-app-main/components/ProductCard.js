import Link from 'next/link';
import Image from 'next/image';
const ProductCard = ({ product }) => {
  return (
    <Link   href="/article/[id]" as={`/article/${product.id}`}>
      <a className="group">
        <div className="w-full bg-gray-200 rounded-3xl overflow-hidden">
          <div className="relative group-hover:opacity-75 h-72">
            <Image className="object-cover object-center " width="500" height="600" loading="lazy"
              src={product.img.img1}
              alt='image'
              // layout="contain"
            />
          </div>
        </div>
        <h3 className="mt-4 text-lg font-medium text-gray-900 ">
        {product.title}
          <svg  className="h-5 w-5 ml-2 inline" fill="none" viewBox="0 0 24 24" stroke="currentColor">
  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
</svg> </h3>
        <p className="mt-1 text-sm overflow-hidden text-gray-700">{product.body}</p>
      </a>
    </Link>
  )
}

export default ProductCard