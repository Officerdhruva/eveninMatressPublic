import jsonwebtoken from "jsonwebtoken";
import dbConnect from "../../dbconnection/connectdb";
import Ru from '../../models/model'
export default async function handler(req,res){
    let dbconnection=false;
    if(!dbconnection){
        await dbConnect();
        dbconnection=true;
    }
    try{
   
    const {email,password}=req.body;
    const exist =await Ru.findOne({email})
    
    if(!email){
        return res.send('user does not exist');

        
    }
    if(password!==exist.password){
        return res.send('passwords are not matching');
    }
    let payload={
        user:{
            id:exist.id
        }
    }
    const token =jsonwebtoken.sign(payload,'djdjfojgoi',(err,token)=>{
        if (err) throw err
        return res.json({token})
    });

}
catch(err){
    return res.send('server error');
}
    
}