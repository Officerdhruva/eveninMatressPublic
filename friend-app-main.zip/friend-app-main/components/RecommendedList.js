 import ProductCard from "./ProductCard"
import products from '../data/mattress.json'
import pillow from '../data/pillow.json'
import protectors from '../data/protector.json'
let filterdProducts
const RecommendedList = ({  current }) => {
 
           if(current<11){
               if (current<5) {
                filterdProducts = products.filter(product=>product.id!=current)
               } else if (current<8) {
                filterdProducts = pillow.filter(product=>product.id!=current)


               } else {
                filterdProducts = protectors.filter(product=>product.id!=current)



               }
              }

  return (
    <div className="bg-white">
      <div className="max-w-2xl mx-auto py-16 px-4 sm:py-24 sm:px-6 lg:max-w-7xl lg:px-8">
        <h2 className="text-2xl font-extrabold text-gray-900 mb-6">
          Recommended Products
        </h2>
        <div className="grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 xl:gap-x-8">
           {
           filterdProducts.map(product => (
             <ProductCard key={product.id} product={product} />
            ))
          } 
          
        </div>
      </div>
    </div>
  )
}

export default RecommendedList
