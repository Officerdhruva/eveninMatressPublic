import jwt from "jsonwebtoken";

const authurize = (handler)=>{
    return async (req,res)=>{
        try{
            const token = req.headers['token'];
            if(!token){
                return res.status(400).send('token does not exist');

            }
        const verify = jwt.verify(token,'djdjfojgoi');

        req.user=verify.user;
        

        return handler(req,res);

        }
        catch(err){
            console.log(err);
            return res.send('invalid token')
        }
        
    }
}
export default authurize