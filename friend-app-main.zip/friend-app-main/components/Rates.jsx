const Rates = () => {
    return (
        
              <table className=" shadow-lg bg-white ">
                <thead >
                  <tr>
                    
                    <th className="bg-blue-100 border text-left px-8 py-3 " >SIZE </th>
                    <th className="bg-blue-100 border text-left px-8 py-3 ">MRP</th>
                    
                  </tr>
                </thead>
                <tbody  >
                  <tr >
                    <td className="border px-8 py-3"> 72x30x5</td>
                    <td className="border px-8 py-3"> &#x20B9; 5720  </td>
                  </tr>
                  <tr>
                    <td className="border px-8 py-3">75x36x6</td>
                    <td className="border px-8 py-3"> &#x20B9; 6765</td>
                  </tr>
                  <tr>
                    <td className="border px-8 py-3">75x48x6</td>
                    <td className="border px-8 py-3"> &#x20B9; 9020</td>
                  </tr>
                  <tr>
                    <td className="border px-8 py-3">75x60x6</td>
                    <td className="border px-8 py-3"> &#x20B9; 11330</td>
                  </tr>
                  <tr>
                    <td className="border px-8 py-3">78x60x6</td>
                    <td className="border px-8 py-3"> &#x20B9; 11880</td>
                  </tr>
                  <tr>
                    <td className="border px-8 py-3">75x72x6</td>
                    <td className="border px-8 py-3"> &#x20B9; 13640</td>
                  </tr>
                  <tr>
                    <td className="border px-8 py-3">78x72x6</td>
                    <td className="border px-8 py-3"> &#x20B9; 14520</td>
                  </tr>
                </tbody>
              </table>  
        
    );
}

export default Rates;