
import Head from 'next/head';
import {  FaRegEnvelope , FaUserCircle} from "react-icons/fa";
import {MdLockOutline } from 'react-icons/md'
import { useEffect, useState } from 'react';
import axios from 'axios';
import { useRouter } from 'next/router';
export default function Register() {
  const [data, setData] = useState(null);
  const router = useRouter();
  useEffect(() => {
    if(data==="Rigister succesfully"){

    router.push('/login')
    }
  
    
  }, [data])
  
    
    
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [conformpassword, setConformpassword] = useState('');
    const submitHandler =(e)=>{
        e.preventDefault();
         axios.post('http://localhost:3000/api/register',{username,email,password,conformpassword}).then(res=>setData(res.data))
        
        
        
    }
  return (
<div className="flex flex-col items-center justify-center min-h-screen py-2 bg-gray-100">


  <Head>
   <title> Register page </title>
   <link rel="icon" href="/favicon.ico"/>
  </Head>
  <main className=' flex flex-col items-center justify-center w-full flex-1 lg:px-20  px-2 text-center '>

    <div className=' bg-white    rounded-2xl shadow-2xl   max-w-4xl '>
      <div className=' flex  justify-center  p-10 ' >
      <form onSubmit={submitHandler}>

        <div className=' text-center font-bold   '>
          <span className='  text-green-500'>Evinin</span> Matress
        </div>
          <h2 className=' text-3xl font-bold text-green-500 mb-2'> Register now </h2> 
        <div className=' border-2 w-10 border-green-500 bg-green-500 rounded-full inline-block mb-2'></div>
 
   {/* complete icons section    */}
<div className=' flex flex-col items-center'>
<div className=' bg-gray-100 w-64 p-2 flex items-center mb-3'>
  <FaUserCircle className=' text-gray-500 mr-2 '/>
  <input type="text" name="username" placeholder='Enter your name' value={username} onChange={e=>setUsername(e.target.value)}  className=' bg-gray-100 outline-none text-sm    flex-1' />

</div>
<div className=' bg-gray-100 w-64 p-2 flex items-center mb-3'>
  <FaRegEnvelope className=' text-gray-500 mr-2 '/>
  <input type="email" name="email" placeholder='Enter email' value={email} onChange={e=>setEmail(e.target.value)} className=' bg-gray-100 outline-none text-sm    flex-1' />

</div>
<div className=' bg-gray-100 w-64 p-2 flex items-center mb-3'>
  <MdLockOutline className=' text-gray-500 mr-2'/>
  <input type="password" name="password"  placeholder='Enter password' value={password} onChange={e=>setPassword(e.target.value)} className=' bg-gray-100 outline-none text-sm    flex-1' />

</div>
<div className=' bg-gray-100 w-64 p-2 flex items-center'>
  <MdLockOutline className=' text-gray-500 mr-2'/>
  <input type="password" name="confirm password"  placeholder='confirm password' value={conformpassword} onChange={e=>setConformpassword(e.target.value)} className=' bg-gray-100 outline-none text-sm    flex-1' />

</div>
      </div>
      {
        data && 
        
          <p className=' text-sm'>{data}</p>
      
      }

<button href="#" className=' border-2  mt-5 border-green-500  text-green-500 rounded-full px-12 py-2 inline-block  hover:bg-green-500  hover:text-white'>Register </button>

</form>
        </div>
     
     
    </div>
    
  </main>
</div>
    )
}