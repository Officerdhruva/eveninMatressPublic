import MattressList from "../components/MattressList"
import PillowList from "../components/PillowList"
import ProtectorList from "../components/ProtectorList"
import Hero from "../components/Hero"
import Head from 'next/head'
import mattress from '../data/mattress.json'
import pillow from '../data/pillow.json'
import protectors from '../data/protector.json'




export default function Home() {

  return (
    <div className="">
      <Head>
      <title>Mattresses  in Nellore </title>
    <meta name="description" content="Best Mattresses , pillow, mattresses protectors in Nellore" />
    <meta name="keywords" content="Best mattresses in nellore" />
    <link rel="icon" type="image/png" href="/favicon.png" />
      
      </Head>
      <div className="flex mx-3 mt-5 text-lg
       justify-between">
      <div>GSTIN : 37CMYPB9952J1Z4</div>
       <div>  <h2 className="text-xl">Krishna ... </h2>
         
      </div>
  </div>
       <Hero />
      <MattressList products={mattress} />
      <PillowList products={pillow } />
      <ProtectorList products={protectors} /> 


    </div>
  )
}


